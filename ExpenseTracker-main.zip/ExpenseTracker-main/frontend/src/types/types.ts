export interface Settings {
  theme: "system" | "light" | "dark";
  currency: `${string}${string}${string}`;
}
